# GalgameMap AstrBot 插件使用说明

当前版本：**beta0.5**。

这个插件用于在 AstrBot 中查询 GalgameMap 信息，并把同好会成员加入申请同步到群聊或私聊。beta0.5 起，站点超管还可以查询与同步 GalOnly 活动的摊位（booth）和 Staff 申请，摊位制品图片会随消息转发。

插件压缩包可以从网站同好会管理后台「Bot 接入」页签下载，或直接访问：

- https://www.map.vnfest.top/downloads/astrbot_plugin_galgamemap_beta0.5.zip

详细使用说明（含命令返回示例）见 VNFest 使用文档：

- https://www.map.vnfest.top/wiki/guide/#/astrbot/install-and-sync

你可以按身份选择接入方式：

- 同好会负责人：使用网站后台生成的 `gmap_club_...` Bot token，只管理自己的同好会。
- 站点超管：使用站点 `config.php` 里的全站 `BOT_API_KEY`，可以使用全站查询和超管同步。

不要把全站 `BOT_API_KEY` 发给普通同好会负责人。普通负责人只应使用「Bot 接入」页签生成的同好会 token。

## 负责人公开接入

适合想把本同好会待审申请同步到群里的负责人或管理员。

### 1. 在网站后台创建 token

1. 登录 GalgameMap 网站。
2. 进入自己的同好会管理后台。
3. 打开「Bot 接入」页签。
4. 创建一个 `gmap_club_...` 开头的 Bot token。
5. 如果希望在群里执行 `/gal地图 通过` 或 `/gal地图 拒绝`，创建 token 时勾选「允许插件审批本同好会申请」。
6. 立刻复制 token。token 明文只显示一次，丢失后需要吊销并重新创建。

### 2. 填写 AstrBot 插件配置

最小配置示例：

```yaml
api_base_url: "https://www.map.vnfest.top"
bot_api_key: "gmap_club_这里填网站后台生成的token"
cache_ttl: 1800
max_results: 15
owner_ids:
  - "你的平台用户ID"
full_access_group_ids: []
sync_enabled: false
sync_auto_enable_on_bind: true
sync_interval_seconds: 120
sync_first_run_silence: true
sync_max_items_per_tick: 10
auto_approve_on_sync: false
```

`owner_ids` 必须填写。同步绑定、同步开关、待审列表、通过和拒绝命令都只允许 `owner_ids` 中的用户执行，避免群内普通成员误操作。

不知道自己的平台用户 ID 时，可以在 AstrBot 中用 `/sid` 查看。

### 3. 在目标群或私聊绑定同步

由 `owner_ids` 中的用户，在要接收提醒的群聊或私聊中依次发送：

```text
/gal地图 同步绑定
/gal地图 同步开启
/gal地图 同步检测
```

同好会公开 token 下，`/gal地图 同步绑定` 不需要填写同好会名。插件会自动绑定 token 所属同好会。

以后可以用下面两条命令查看状态：

```text
/gal地图 同步状态
/gal地图 同步配置
```

## 站点超管私有接入

站点超管可以使用 `config.php` 中的全站 `BOT_API_KEY`。

```yaml
api_base_url: "https://www.map.vnfest.top"
bot_api_key: "config.php 中的 BOT_API_KEY"
owner_ids:
  - "超管平台用户ID"
```

全站密钥可以跨同好会查询，也可以把全站待审申请同步到指定会话。

常用示例：

```text
/gal地图 管理概览
/gal地图 full china:2
/gal地图 同步超管
/gal地图 同步绑定 北大
/gal地图 同步绑定 china:2
/gal地图 同步搜索 北大
/gal地图 同步检测 北大
```

## 常用命令

### 基础查询

```text
/gal地图
/galmap
/gal地图 搜索 北大
/gal地图 地区 广东
/gal地图 国家 日本
/gal地图 类型 高校
/gal地图 详情 china:2
/gal地图 分享 china:2
/gal地图 活跃 china:2
/gal地图 刊物 writing
/gal地图 活动 近期
/gal地图 wiki 盐工
/gal地图 星图 华东
/gal地图 萌战
/gal地图 公告
/gal地图 统计
```

同好会公开 token 可以跨同好会查询公开资料（列表、搜索、详情），但不能读取隐私字段、申请数据或管理功能。

### 申请处理

```text
/gal地图 待审
/gal地图 通过 123
/gal地图 拒绝 123 信息不完整
```

审批命令需要同时满足：

- 发送者在 `owner_ids` 中。
- token 创建时勾选了「允许插件审批本同好会申请」。

### 同步管理

```text
/gal地图 同步绑定
/gal地图 同步绑定 北大
/gal地图 同步搜索 北大
/gal地图 同步解绑 北大
/gal地图 同步状态
/gal地图 同步配置
/gal地图 同步检测
/gal地图 同步检测 北大
/gal地图 同步开启
/gal地图 同步关闭
/gal地图 同步超管
/gal地图 同步取消超管
```

说明：

- `同步绑定`：把当前群聊或私聊设为接收提醒的位置。
- `同步开启`：打开本地运行时同步。
- `同步检测`：手动检查一次待审申请。
- `同步搜索 北大`：全站密钥下，用关键词查找可绑定的同好会。
- `同步超管`：全站密钥下，把所有同好会待审申请同步到当前会话。

### GalOnly 查询与同步（超管专属，beta0.5）

以下命令仅在使用全站 `BOT_API_KEY` 时可用，同好会公开 token 会被拒绝。

```text
/gal地图 galonly
/gal地图 galonly 摊位 上海
/gal地图 galonly staff 上海
/gal地图 galonly 详情 12
/gal地图 同步galonly
/gal地图 取消galonly
/gal地图 galonly状态
/gal地图 galonly检测
```

说明：

- `galonly`：列出所有 GalOnly 活动，以及各活动待审摊位和 Staff 数量。
- `galonly 摊位 上海`：查看某活动的摊位申请列表；活动按名称、地点或活动码匹配，多个候选时会列出供选择。
- `galonly staff 上海`：查看某活动的 Staff 申请列表。
- `galonly 详情 12`：查看单个摊位或 Staff 申请完整信息，摊位详情包含制品图片链接。
- `同步galonly`：把当前群聊或私聊设为 GalOnly 申请推送目标，自动开启运行时同步。
- `取消galonly`：取消当前会话的 GalOnly 推送。
- `galonly状态`：查看 GalOnly 同步目标与最近同步进度。
- `galonly检测`：立即拉取一次新申请并推送。

摊位申请推送时会随消息转发制品图片（最多 4 张）；图片发送失败时自动降级为文本加图片链接。Staff 申请推送包含姓名、QQ、邮箱、岗位、出勤与技能等信息。两类申请只在 GalOnly 同步会话中推送，普通社团同步不会收到。

## 配置项说明

| 配置项 | 建议值 | 说明 |
| --- | --- | --- |
| `api_base_url` | `https://www.map.vnfest.top` | GalgameMap 站点地址。 |
| `bot_api_key` | `gmap_club_...` 或全站 `BOT_API_KEY` | 插件访问 Bot API 的密钥。 |
| `owner_ids` | 管理员用户 ID 列表 | 允许执行管理命令的用户。 |
| `full_access_group_ids` | 通常留空 | 白名单群会展示更完整的信息。 |
| `cache_ttl` | `300` 到 `3600` | 接口缓存秒数。填 `0` 可关闭缓存。 |
| `max_results` | `10` 到 `20` | 列表命令最多展示条数。 |
| `sync_enabled` | `false` | 配置页总开关。通常可保持 false，通过命令启用。 |
| `sync_auto_enable_on_bind` | `true` | 绑定后自动启用同步。 |
| `sync_interval_seconds` | `60` 到 `300` | 自动检查待审申请的间隔。 |
| `sync_first_run_silence` | `true` | 首次启动只记录基线，不推送历史积压申请。 |
| `sync_max_items_per_tick` | `10` | 每轮每个目标最多推送多少条。 |
| `auto_approve_on_sync` | `false` | 检测到申请时自动通过。仅建议在可信场景开启。 |

## 权限边界

`gmap_club_...` 同好会 token：

- 可以查询全站同好会公开资料（列表、搜索、详情，仅公开字段）。
- 可以查询公告、活动、刊物、Wiki、星图等公开内容（刊物投稿联系方式仍隐藏）。
- 只能读取本同好会待审申请。
- 只能访问本同好会分享和活跃信息。
- 不能读取 `full/include_private` 隐私数据。
- 不能使用 `管理概览`。
- 不能使用 `同步超管`。
- 不能使用 GalOnly 查询与同步。
- 默认不能审批，除非创建 token 时勾选审批权限。

全站 `BOT_API_KEY`：

- 可以全站查询。
- 可以使用 `管理概览`。
- 可以使用 `full` 完整资料查询。
- 可以使用 `同步超管`。
- 可以跨同好会绑定同步。
- 可以查询与同步 GalOnly 摊位和 Staff 申请（含制品图片转发）。

## Bot API

插件访问 `api/bot.php`。

认证方式：

```bash
curl -H "Authorization: Bearer gmap_club_xxx" \
  "https://www.map.vnfest.top/api/bot.php?action=membership_applications&status=pending"
```

公开 token 常用 action：

- `help`
- `clubs` / `search`
- `club`
- `club_share`
- `club_activity`
- `membership_applications`
- `membership_approve`，需要 `approve_membership` 权限
- `membership_reject`，需要 `approve_membership` 权限
- `stats`

全站密钥（beta0.5 新增）GalOnly action：

- `galonly_events`
- `galonly_applications`，摊位申请，含 `image_paths` 绝对图片 URL
- `galonly_staff_applications`，Staff 申请

以上三个 GalOnly action 仅全站 `BOT_API_KEY` 可用，同好会 token 请求会返回 403。

后台登录态可用的 token 管理 action：

- `bot_tokens_list`
- `bot_tokens_create`
- `bot_tokens_revoke`

## 常见问题

### 提示“Bot API 密钥无效或未配置”

检查 `bot_api_key` 是否完整复制。同好会公开 token 应以 `gmap_club_` 开头。

### 提示“同好会 Bot token 无权访问其他同好会”

该提示仅出现在访问其他同好会的申请、分享/活跃或私有数据时。跨同好会的公开查询（列表、搜索、详情）已开放；申请数据、`full` 隐私数据和管理功能仍需站点超管全站密钥。

### 提示“该 token 未开启审批权限”

当前 token 是只读 token。请在网站后台吊销旧 token，重新创建时勾选「允许插件审批本同好会申请」。

### 提示“GalOnly 查询与同步仅全站 Bot API 密钥可用”

GalOnly 是超管专属功能。请使用站点 `config.php` 中的全站 `BOT_API_KEY` 配置插件，不要在负责人 token 下尝试。

### 提示“不合法的 session 字符串”

不要在配置里手填 QQ 群号。主动推送必须使用 AstrBot 的 `unified_msg_origin`。

处理方法：在目标群聊或私聊中重新执行：

```text
/gal地图 同步绑定
```

### 没有收到同步提醒

按顺序检查：

1. `bot_api_key` 是否有效。
2. 执行命令的人是否在 `owner_ids` 中。
3. 是否在目标群聊或私聊执行过 `/gal地图 同步绑定`。
4. 是否执行过 `/gal地图 同步开启`。
5. `/gal地图 同步状态` 是否显示已绑定且启用。
6. `/gal地图 同步检测` 是否能手动拉取申请。
