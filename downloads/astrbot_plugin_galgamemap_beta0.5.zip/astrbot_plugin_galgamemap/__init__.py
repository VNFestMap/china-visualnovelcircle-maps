from .main import GalgameMapPlugin

__all__ = ["GalgameMapPlugin"]
